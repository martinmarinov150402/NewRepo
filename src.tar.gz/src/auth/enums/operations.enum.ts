export enum Operations{
    Grant=1,
    Revoke=2,
    AccessAllTasks=3,
    AccessOwnTasks=4,
}