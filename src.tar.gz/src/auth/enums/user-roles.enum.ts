export enum UserRoles{
    User = "USER",
    Admin = "ADMIN",
}