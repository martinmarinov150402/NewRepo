export let configObject = {
    db_username:'1111',
    db_password:'1111',
    db_host:'localhost',
    db_port:5432,
    db_name:'1111',
    jwt_secret:'SecretASD',
    port:3000,
    db_sync:true,
};